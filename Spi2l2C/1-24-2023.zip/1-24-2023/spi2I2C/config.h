
//Some screens like difference contrast values. So I couldn't really set a good default value
//Play around and adjust to suit your screen. If you have flickering issues, it may help to solder
//an extra electrolytic capacitor between the contrast pin (normally labelled 'V0') and GND.
#define DEFAULT_CONTRAST 89  //0-255. Lower is higher contrast.
#define DEFAULT_BACKLIGHT 255 //0-255. Higher is brighter.

//Uncomment this line to make the in-game temp readouts display in Fahrenheit.
#define USE_FAHRENHEIT 1 

// this is where you can configure the addresses in HEX format
//#define LCDPRIMARY     0x25 //(A0=0x27, A1=0x25)
//#define LCDSECONDARY     0x27 //(A0=0x27, A1=0x25)
#define OLEDPRIMARY    0x3C // SA0->gnd=0x3C SA0->3.3v=0x3D
#define OLEDSECONDARY    0x3D // SA0->gnd=0x3C SA0->3.3v=0x3D

// this is where you setup your mono/dual screen config. valid choice are : 
// "us2066" for newheaven display oled character display or US2066 compatible oleds. 
// "ssd1306-spi" for 128x64 monochrome oled like the 2inch model from wide.hk NOT CODED YET
// "ssd1306-i2c" for 128x64 monochrome oled from ebay or adafruit NOT CODED YET
// "lcd2004"  for bog standard 20x4 hitachi hd44780 compatible lcd with the i2c backpack
// "lcd1602"  for bog standard 16x2 hitachi hd44780 compatible lcd with the i2c backpack
// "NONE" for disabling the Secondary screen 
#define mainScreenType "us2066"
#define secScreenType "us2066" 

#define primaryBurnIn   "disable"
#define secondaryBurnIn "disable"

//here you have to specify the amount of adressable rgb leds you have installed
//#define NUM_LEDS 20
//#define BOOT_LEDS Green 
//#define BRIGHT_LEDS 255  // max brightness level 0-255
//#define TYPE_LEDS WS2811 // TM1803 TM1804 TM1809 WS2811 WS2812 WS2812B NEOPIXEL APA104 WS2811_400 GW6205 GW6205_400 UCS1903 UCS1903B
