  // This Arduino program set is for OLED (US2066) screens, and HD44780 screens with an I2C backpack.
  //// If an I2C backpack with HD44780 screen is used, it must have the "PCF8574T" chip, NOT the "PCF8574AT" chip.
  
  // Choose what the "Primary" screen shows when XBMC dashboard is running (including XBMC4Gamers variant) by editing the "XBMC/system/UserData/LCD.xml" file.
  //// https://redmine.exotica.org.uk/projects/xbmc4xbox/repository/xbmc4xbox/entry/branches/3.5/xbmc/GUIInfoManager.cpp

  // If you have flickering issues, it may help to solder an extra electrolytic capacitor between the contrast pin (normally labelled 'V0') and "GND".
#define DEFAULT_CONTRAST 89  //0-255. Lower is higher contrast.
#define DEFAULT_BACKLIGHT 255 //0-255. Higher is brighter.

  // ~~Select wether the temperature is shown on the screen in Celcius (C) or Fahrenheit (F)~~
#define USE_FAHRENHEIT 1  // Uncomment this line to make the temp readouts show in Fahrenheit.

  // ~~Select "Primary (main)" and "Secondary (sec)" screen addresses~~
#define OLEDPRIMARY    0x3C  // (SA0->gnd=0x3C, SA0->3.3v=0x3D) OLED address in HEX format.
#define OLEDSECONDARY    0x3D  // (SA0->gnd=0x3C, SA0->3.3v=0x3D) OLED address in HEX format.

  // ~~Select "Primary (main)" and "Secondary (sec)" screen types~~
  //// Valid choices are:
  //// "OLED200x" for NewHeaven 20x4 or 20x2 OLED character screen or US2066 compatible OLED screen.
  //// "OLED1602" for NewHeaven 16x2 OLED character screen or US2066 compatible OLED screen.
  //// "NONE" to disable.
#define mainScreenType "OLED200x"  // Primary screen type.
#define secScreenType "NONE"  // Secondary screen type.

  // ~~Select "Primary (main)" and "Secondary (sec)" screen BurnIn~~
  //// Screen scrolling can be enabled to combat the burn in pixel effect that could happen over time.
#define primaryBurnIn   "disable"  // (enable, disable) Primary screen BurnIn.
#define secondaryBurnIn "disable"  // (enable, disable) Secondary screen BurnIn.
